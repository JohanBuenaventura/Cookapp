package com.example.cookapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.cookapp.adapter.MyRecipesAdapter
import com.example.cookapp.databinding.ActivityMyRecipesBinding
import com.example.cookapp.models.RecipeModel
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import org.json.JSONArray
import org.json.JSONObject

class MyRecipes : AppCompatActivity() {

    private lateinit var bind: ActivityMyRecipesBinding
    private lateinit var adapter: MyRecipesAdapter
    private val list = ArrayList<RecipeModel>()
    private lateinit var drawerLayout: DrawerLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        bind = ActivityMyRecipesBinding.inflate(layoutInflater)
        setContentView(bind.root)

        drawerLayout = bind.drawerLayout

        // Edge-to-edge padding
        ViewCompat.setOnApplyWindowInsetsListener(bind.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // RecyclerView setup
        adapter = MyRecipesAdapter(list)
        bind.recipeRecycler.layoutManager = LinearLayoutManager(this)
        bind.recipeRecycler.adapter = adapter

        // Drawer & top app bar
        bind.topAppBar.setNavigationOnClickListener { drawerLayout.openDrawer(androidx.core.view.GravityCompat.START) }
        bind.navigationDrawer.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_home -> { startActivity(Intent(this, userpage::class.java)); finish() }
                R.id.nav_profile -> startActivity(Intent(this, Profile::class.java))
                R.id.nav_about -> startActivity(Intent(this, AboutUs::class.java))
                R.id.nav_signout -> {
                    val intent = Intent(this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    finish()
                }
            }
            drawerLayout.closeDrawer(androidx.core.view.GravityCompat.START)
            true
        }

        // Bottom navigation setup
        bind.bottomNavigationView.selectedItemId = R.id.nav_my_recipes
        bind.bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, userpage::class.java)); finish(); true
                }
                R.id.nav_my_recipes -> {
                    // Already on MyRecipes, do nothing
                    true
                }
                R.id.nav_cookbook -> {
                    startActivity(Intent(this, Uploadrecipe::class.java)); finish(); true
                }
                R.id.nav_notifications -> {
                    startActivity(Intent(this, Notifications::class.java)); finish(); true
                }
                else -> false
            }
        }

        // Load recipes from the server
        loadRecipes()
    }

    private fun loadRecipes() {
        val shared = getSharedPreferences("user", MODE_PRIVATE)
        val userId = shared.getInt("user_id", -1)

        if (userId == -1) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
            return
        }

        val url = "http://192.168.1.3/cookbook_api/get_my_recipes.php"

        val request = object : StringRequest(Request.Method.POST, url,
            { response ->
                try {
                    val json = JSONObject(response)
                    if (json.getBoolean("success")) {
                        val arr: JSONArray = json.getJSONArray("recipes")
                        list.clear()
                        for (i in 0 until arr.length()) {
                            val obj = arr.getJSONObject(i)
                            list.add(
                                RecipeModel(
                                    obj.getInt("id"),
                                    obj.getString("title"),
                                    obj.getString("ingredients"),
                                    obj.getString("image_path")
                                )
                            )
                        }
                        adapter.notifyDataSetChanged()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(this, "Parsing error", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                Toast.makeText(this, "Network error: ${error.message}", Toast.LENGTH_SHORT).show()
            }) {
            override fun getParams(): MutableMap<String, String> {
                return hashMapOf("user_id" to userId.toString())
            }
        }

        Volley.newRequestQueue(this).add(request)
    }
}
