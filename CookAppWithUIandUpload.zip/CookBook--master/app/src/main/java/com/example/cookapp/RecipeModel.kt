package com.example.cookapp.models

data class RecipeModel(
    val id: Int,
    val title: String,
    val ingredients: String,
    val image_path: String?
)
