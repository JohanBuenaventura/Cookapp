package com.example.cookapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.bumptech.glide.Glide
import com.example.cookapp.databinding.ActivityProfileBinding
import com.google.android.material.navigation.NavigationView
import org.json.JSONObject

class Profile : AppCompatActivity() {

    private lateinit var bind: ActivityProfileBinding
    private var isEditing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        bind = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(bind.root)

        // Edge-to-edge padding
        ViewCompat.setOnApplyWindowInsetsListener(bind.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Drawer toggle
        bind.topAppBar.setNavigationOnClickListener {
            bind.drawerLayout.openDrawer(androidx.core.view.GravityCompat.START)
        }

        // Drawer menu actions
        bind.navigationDrawer.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, userpage::class.java))
                    finish()
                }
                R.id.nav_profile -> {
                    bind.drawerLayout.closeDrawer(androidx.core.view.GravityCompat.START)
                }
                R.id.nav_about -> {
                    startActivity(Intent(this, AboutUs::class.java))
                }
                R.id.nav_signout -> {
                    val intent = Intent(this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    finish()
                }
            }
            bind.drawerLayout.closeDrawer(androidx.core.view.GravityCompat.START)
            true
        }

        // Bottom navigation
        bind.bottomNavigationView.selectedItemId = R.id.nav_profile
        bind.bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, userpage::class.java))
                    finish()
                    true
                }
                R.id.nav_my_recipes -> {
                    startActivity(Intent(this, MyRecipes::class.java))
                    finish()
                    true
                }
                R.id.nav_cookbook -> {
                    startActivity(Intent(this, Uploadrecipe::class.java))
                    finish()
                    true
                }
                R.id.nav_notifications -> {
                    startActivity(Intent(this, Notifications::class.java))
                    finish()
                    true
                }
                else -> false
            }
        }

        // Update / Save button
        bind.btnAction.setOnClickListener {
            if (!isEditing) {
                isEditing = true
                setEditingEnabled(true)
                bind.btnAction.text = "Save Changes"
                bind.etName.requestFocus()
            } else {
                val newName = bind.etName.text.toString().trim()
                if (newName.isEmpty()) {
                    bind.etName.error = "Name cannot be empty"
                } else {
                    Toast.makeText(this, "Profile Updated!", Toast.LENGTH_SHORT).show()
                    isEditing = false
                    setEditingEnabled(false)
                    bind.btnAction.text = "Update"
                    // TODO: send updated info to API if needed
                }
            }
        }

        // Initial state
        setEditingEnabled(false)

        // Load user data automatically
        loadUserProfile()
    }

    private fun setEditingEnabled(enabled: Boolean) {
        bind.etName.isEnabled = enabled
        bind.etBio.isEnabled = enabled
    }

    private fun loadUserProfile() {
        val shared = getSharedPreferences("user", MODE_PRIVATE)
        val userId = shared.getInt("user_id", -1)

        if (userId == -1) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
            return
        }

        val url = "http://192.168.1.3/cookbook_api/get_user.php"

        val request = object : StringRequest(Request.Method.POST, url,
            { response ->
                try {
                    val json = JSONObject(response)
                    if (json.getBoolean("success")) {
                        val user = json.getJSONObject("user")
                        bind.etName.setText("${user.getString("firstname")} ${user.getString("lastname")}")

                        bind.etBio.setText(user.optString("bio", ""))
                        val profileImage = user.optString("profile_image", "default.png")
                        Glide.with(this)
                            .load("http://192.168.1.3/cookbook_api/uploads/$profileImage")
                            .placeholder(R.drawable.placeholder)
                            .into(bind.ivProfileImage)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(this, "Error parsing profile data", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                Toast.makeText(this, "Network error: ${error.message}", Toast.LENGTH_SHORT).show()
            }) {
            override fun getParams(): MutableMap<String, String> {
                return hashMapOf("user_id" to userId.toString())
            }
        }

        Volley.newRequestQueue(this).add(request)
    }
}
