package com.example.cookapp.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.cookapp.databinding.ItemRecipeBinding
import com.example.cookapp.models.RecipeModel
import com.example.cookapp.R

class MyRecipesAdapter(private val recipes: List<RecipeModel>) :
    RecyclerView.Adapter<MyRecipesAdapter.ViewHolder>() {

    inner class ViewHolder(val bind: ItemRecipeBinding) : RecyclerView.ViewHolder(bind.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemRecipeBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val recipe = recipes[position]

        holder.bind.tvRecipeName.text = recipe.title
        holder.bind.tvIngredients.text = recipe.ingredients

        Glide.with(holder.itemView.context)
            .load("http://192.168.1.3/cookbook_api/uploads/${recipe.image_path}")
            .placeholder(R.drawable.placeholder)
            .into(holder.bind.ivRecipeImage)
    }

    override fun getItemCount(): Int = recipes.size
}
