package com.example.cookapp.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.cookapp.databinding.ItemHomeRecipeBinding
import com.example.cookapp.models.HomeRecipeModel

class HomeRecipesAdapter(private val recipes: List<HomeRecipeModel>) :
    RecyclerView.Adapter<HomeRecipesAdapter.HomeRecipeViewHolder>() {

    inner class HomeRecipeViewHolder(val binding: ItemHomeRecipeBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(recipe: HomeRecipeModel) {
            binding.tvTitle.text = recipe.title
            binding.tvIngredients.text = recipe.ingredients
            binding.tvUploaderName.text = "${recipe.firstname} ${recipe.lastname}"

            // Load image if exists
            if (!recipe.image_path.isNullOrEmpty()) {
                Glide.with(binding.ivRecipeImage.context)
                    .load(recipe.image_path)
                    .into(binding.ivRecipeImage)
            } else {
                binding.ivRecipeImage.setImageResource(android.R.drawable.ic_menu_report_image)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomeRecipeViewHolder {
        val binding = ItemHomeRecipeBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return HomeRecipeViewHolder(binding)
    }

    override fun onBindViewHolder(holder: HomeRecipeViewHolder, position: Int) {
        holder.bind(recipes[position])
    }

    override fun getItemCount(): Int = recipes.size
}
