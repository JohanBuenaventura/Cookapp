package com.example.cookapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.cookapp.databinding.ActivitySignupBinding
import org.json.JSONObject

class Signup : AppCompatActivity() {

    private lateinit var bind: ActivitySignupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(bind.root)

        bind.btnSignUp.setOnClickListener {
            val first = bind.etFirstName.text.toString().trim()
            val last = bind.etLastName.text.toString().trim()
            val email = bind.etEmail.text.toString().trim()
            val pass = bind.etPassword.text.toString().trim()

            if (first.isEmpty() || last.isEmpty() || email.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show()
            } else {
                registerUser(first, last, email, pass)
            }
        }

        bind.tvSwitchLogin.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
    }

    private fun registerUser(first: String, last: String, email: String, pass: String) {

        val url = "http://192.168.1.3/cookbook_api/signup.php"

        val request = object : StringRequest(
            Request.Method.POST, url,
            { response ->
                val json = JSONObject(response)
                if (json.getBoolean("success")) {
                    Toast.makeText(this, "Account created!", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(this, json.getString("message"), Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                Toast.makeText(this, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getParams(): MutableMap<String, String> {
                return hashMapOf(
                    "firstname" to first,
                    "lastname" to last,
                    "email" to email,
                    "password" to pass
                )
            }
        }

        Volley.newRequestQueue(this).add(request)
    }
}
