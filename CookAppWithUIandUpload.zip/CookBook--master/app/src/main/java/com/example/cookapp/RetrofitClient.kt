import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    // 10.0.2.2 is "localhost" for the Android Emulator
    // If using a real phone, use your PC's IP address (e.g., http://192.168.1.5/cookbook_api/)
    private const val BASE_URL = "http://10.0.2.2/cookbook_api/"

    val instance: CookbookApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(CookbookApi::class.java)
    }

    // Helper to get full image URL
    fun getImageUrl(relativePath: String?): String {
        return if (relativePath.isNullOrEmpty()) "" else "$BASE_URL$relativePath"
    }
}