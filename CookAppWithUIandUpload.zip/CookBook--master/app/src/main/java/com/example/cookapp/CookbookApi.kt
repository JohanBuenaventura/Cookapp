import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

interface CookbookApi {

    // 1. Login
    @FormUrlEncoded
    @POST("login.php")
    suspend fun login(
        @Field("email") email: String,
        @Field("password") pass: String
    ): Response<LoginResponse>

    // 2. Get All Recipes
    @GET("get_recipes.php")
    suspend fun getRecipes(): Response<List<Recipe>>

    // 3. Upload Recipe (Multipart)
    @Multipart
    @POST("upload_recipe.php")
    suspend fun uploadRecipe(
        @Part("user_id") userId: RequestBody,
        @Part("recipe_name") title: RequestBody,
        @Part("ingredients") ingredients: RequestBody,
        @Part image: MultipartBody.Part?
    ): Response<UploadResponse> // Create a simple data class for this response
}

class LoginResponse {

}

class Recipe {

}

class UploadResponse {

}
