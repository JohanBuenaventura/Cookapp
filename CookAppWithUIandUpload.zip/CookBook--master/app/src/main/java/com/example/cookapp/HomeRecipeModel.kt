package com.example.cookapp.models

data class HomeRecipeModel(
    val id: Int,
    val title: String,
    val ingredients: String,
    val image_path: String?,
    val user_id: Int,
    val firstname: String,
    val lastname: String,
    val profile_image: String?
)
