package com.example.cookapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.cookapp.adapters.MyRecipeAdapter
import com.example.cookapp.models.RecipeModel
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import org.json.JSONObject


class MyRecipes : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var recyclerView: RecyclerView
    private val recipeList = ArrayList<RecipeModel>()
    private lateinit var adapter: MyRecipeAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_my_recipes)

        // INITIALIZE NAVIGATION UI
        drawerLayout = findViewById(R.id.drawerLayout)
        val topAppBar = findViewById<MaterialToolbar>(R.id.topAppBar)
        val navigationView = findViewById<NavigationView>(R.id.navigationDrawer)
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
        val mainLayout = findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.main)

        // EDGE-TO-EDGE PADDING
        ViewCompat.setOnApplyWindowInsetsListener(mainLayout) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // DRAWER TOGGLE
        topAppBar.setNavigationOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }

        // DRAWER MENU ACTIONS
        navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, userpage::class.java))
                    finish()
                }
                R.id.nav_profile -> {
                    startActivity(Intent(this, Profile::class.java))
                }
                R.id.nav_about -> {
                    startActivity(Intent(this, AboutUs::class.java))
                }
                R.id.nav_signout -> {
                    val intent = Intent(this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    finish()
                }
            }
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }

        // BOTTOM NAVIGATION
        bottomNav.selectedItemId = R.id.nav_my_recipes
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, userpage::class.java))
                    finish()
                    true
                }
                R.id.nav_my_recipes -> true
                R.id.nav_cookbook -> {
                    startActivity(Intent(this, Uploadrecipe::class.java))
                    finish()
                    true
                }
                R.id.nav_notifications -> {
                    startActivity(Intent(this, Notifications::class.java))
                    finish()
                    true
                }
                else -> false
            }
        }

        // RECYCLER VIEW SETUP
        recyclerView = findViewById(R.id.recipeRecycler)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = MyRecipeAdapter(recipeList)
        recyclerView.adapter = adapter

        // FETCH USER RECIPES
        fetchRecipes()
    }

    private fun fetchRecipes() {
        val url = "https://192.168.1.3/cookbook_api/get_user_recipes.php"
        val userId = 1 // TODO: replace with session user ID

        val request = object : StringRequest(Method.POST, url,
            { response ->
                val json = JSONObject(response)
                if (json.getBoolean("success")) {
                    val arr = json.getJSONArray("recipes")

                    recipeList.clear()

                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)

                        recipeList.add(
                            RecipeModel(
                                obj.getInt("id"),
                                obj.getString("recipe_title"),
                                obj.getString("ingredients"),
                                obj.getString("steps"),
                                obj.getString("image")
                            )
                        )
                    }

                    adapter.notifyDataSetChanged()
                }
            },
            { error ->
                Toast.makeText(this, "Network error!", Toast.LENGTH_SHORT).show()
                Log.e("MyRecipes", "Error: ${error.message}")
            }
        ) {
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()
                params["user_id"] = userId.toString()
                return params
            }
        }

        Volley.newRequestQueue(this).add(request)
    }
}
