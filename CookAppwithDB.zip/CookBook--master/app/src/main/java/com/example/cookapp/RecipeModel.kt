package com.example.cookapp.models

data class RecipeModel(
    val id: Int,
    val title: String,
    val ingredients: String,
    val imageUrl: String?,
    val string: String
)
