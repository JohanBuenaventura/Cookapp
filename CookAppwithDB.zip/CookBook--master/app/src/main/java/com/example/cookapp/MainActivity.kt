package com.example.cookapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.cookapp.databinding.ActivityMainBinding
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnMain.setOnClickListener {
            val email = binding.etEmail.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
            } else {
                loginUser(email, password)
            }
        }

        binding.tvToggleAuth.setOnClickListener {
            startActivity(Intent(this, Signup::class.java))
        }
    }

    private fun loginUser(email: String, pass: String) {

        val url = "http://192.168.1.3/cookbook_api/login.php"

        val request = object : StringRequest(
            Request.Method.POST, url,
            { response ->
                val json = JSONObject(response)

                if (json.getBoolean("success")) {

                    val user = json.getJSONObject("user")
                    val id = user.getInt("id")
                    val firstname = user.getString("firstname")

                    Toast.makeText(this, "Welcome $firstname!", Toast.LENGTH_SHORT).show()

                    val intent = Intent(this, userpage::class.java)
                    intent.putExtra("user_id", id)
                    startActivity(intent)
                    finish()

                } else {
                    Toast.makeText(this, json.getString("message"), Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                Toast.makeText(this, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getParams(): MutableMap<String, String> {
                return hashMapOf(
                    "email" to email,
                    "password" to pass
                )
            }
        }

        Volley.newRequestQueue(this).add(request)
    }
}
