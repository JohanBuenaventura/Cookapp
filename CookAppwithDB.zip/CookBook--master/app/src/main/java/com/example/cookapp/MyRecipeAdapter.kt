package com.example.cookapp.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.cookapp.databinding.ItemRecipeBinding
import com.example.cookapp.models.RecipeModel

class MyRecipeAdapter(private val recipeList: List<RecipeModel>) :
    RecyclerView.Adapter<MyRecipeAdapter.RecipeViewHolder>() {

    inner class RecipeViewHolder(val bind: ItemRecipeBinding) :
        RecyclerView.ViewHolder(bind.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecipeViewHolder {
        val binding = ItemRecipeBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return RecipeViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecipeViewHolder, position: Int) {
        val recipe = recipeList[position]

        holder.bind.txtTitle.text = recipe.title
        holder.bind.txtIngredients.text = recipe.ingredients

        Glide.with(holder.itemView.context)
            .load(recipe.imageUrl)
            .placeholder(android.R.drawable.ic_menu_gallery)
            .into(holder.bind.imgRecipe)
    }

    override fun getItemCount(): Int = recipeList.size
}
